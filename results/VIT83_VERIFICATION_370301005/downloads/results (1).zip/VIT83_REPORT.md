# UROP image-only Vision Transformer 83% experiment

Frozen recipe **full_frame**, epoch 3, seed 42.
Full validation accuracy 83.0199% (49,230/59,299).
Independent full-test accuracy **83.1281%** (49,270/59,270).
Difference from 83.00% +0.1281 percentage points. Additional correct predictions needed 0.

| Cohort | Accuracy | Macro-F1 | Balanced accuracy | Imposter Content recall |
|---|---:|---:|---:|---:|
| Full official test (59,270) | 83.1281% | 0.713128 | 69.1492% | 17.2386% |
| No exact training byte match (56,052) | 82.8160% | 0.711142 | 68.9987% | 17.8571% |

| Baseline | Paired difference (pp) | Correct only for new model | Correct only for baseline |
|---|---:|---:|---:|
| ResNet-50 | +1.9723 | 4,694 | 3,525 |
| DeiT III B/16 | +2.7333 | 4,924 | 3,304 |

The CPU verification JSON includes raw and normalized confusion matrices, per-class metrics, paired bootstrap intervals, and cohort and prediction hashes.
The prior models used this official test as well. No separate holdout was registered.
